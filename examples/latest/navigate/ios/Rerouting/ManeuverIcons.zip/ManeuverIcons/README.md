These icons have been downloaded from https://github.com/heremaps/here-icons.

License

Copyright (C) 2017-2023 HERE Europe B.V. The LICENSE.txt in this folder applies to all icon content.