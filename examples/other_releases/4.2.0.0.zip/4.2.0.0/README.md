This folder contains the HERE SDK examples apps for version: 4.2.0.0

- HERE SDK for Android ([Lite Edition](lite/android/))
- HERE SDK for iOS ([Lite Edition](lite/ios/))

