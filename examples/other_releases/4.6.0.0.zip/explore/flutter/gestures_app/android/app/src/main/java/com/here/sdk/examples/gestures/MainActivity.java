package com.here.sdk.examples.gestures;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
