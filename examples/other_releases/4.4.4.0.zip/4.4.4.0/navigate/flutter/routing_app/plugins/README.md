Place the here_sdk plugin folder here!
